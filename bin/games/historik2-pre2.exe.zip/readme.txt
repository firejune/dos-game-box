 .:Thanx for downloading one of our free softwares\Gamez\abandonware:. 
 ---<*************************************************************>---
All rights reserved of course to TAmAx corp. 1999 �
Remember: if you cant beat us, join us!      
_______________________________________________________________________
|This app.\Game\abandonware was downloaded from: Http://www.tamax.da.ru|
-----------------------------------------------------------------------

FREE!!
======
All the games on www.tamax.cjb.net are free and you can pass 
them on to your friends and tell them to visit 
my website to check out the cool abandonware section!!!
Dont forget to give them this readme file so they can 
learn more about this site and how to contact the Webmaster.

Real!!!
======= 
All the gamez on www.tamax.cjb.net are real! they are not leeched 
from other sites. The webmaster spent alot of time and money to 
upload all the gamez in order to give you the best Abandonware Download Website.

Vote for me! 
============
In order to give you the best gamez you must vote for me. please 
let the popup window in the Abandonware section load. By doing that you 
can vote for me. If you vote for me, my Website will be ranked in a higher 
place and will get more traffic and I will have the power to update 
my site with new stuff.

Tell your friends!
==================
In order to increase the amount of traffic on my website you must help me to
spread it all over the net. if you have a website, put my link then;
and contact me so I will put your link in my website, that way both
of our websites will have a higher number of visitors! ( links exchange ;-) 
don't forget to link to: www.tamax.da.ru 
or: www.tamax.cjb.net 
or: www.tamax.tsx.org 
Thanx!

Have a game?
====================
If you have a game/program that is not listed in the abandonware section 
and you would like it to be listed there, you can tell me about it!
just e-mail me and/or send me the game through ICQ, or give 
me an address to download it from, or something like that.

Have a program?
===============
If you have a program (that you made) you can spread her by using my website.
the file must be no bigger than 2 mb. the program must be good!
Just e-mail me with your detail and detail on the program.(and send me 
the program i dont know how... you can send me through ICQ or give 
me an address to download it from, or something like that.)

Contact the Webmaster:
======================
You can contact me by:
e-mail: ooron@newmail.net
ICQ: #17398509
FireTalk: #14400 (its a new program where you can talk with
a microphone with each other in real time...)
Http://www.tamax.da.ru by signing the guestbook.
My real adress:
 
Tamir oron,
Hasomer 4
Kiriat bialik
27237, israel.
flat no. 9

=====================================================================
This Readme file was created on the 28/7/1999 by the Webmaster 
of The official TaMaX Website.  