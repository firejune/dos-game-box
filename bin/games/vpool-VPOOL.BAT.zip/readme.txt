  ------------------------------------------------------------------------
  Interplay Productions     -   Virtual Pool    -            Celeris, Inc.
  ------------------------------------------------------------------------
  This file contains important information about Virtual Pool which is not
  included in the manual or other documentation.

                          ========================
                               Memory Managers
                          ========================
  Virtual Pool does not require a memory manager, but should run ok with
  all of them in most configuations.

  You may have problems running Virtual Pool with QEMM.
  To disable QEMM, push ALT while the system is booting.

                          ========================
                                 Sound Cards
                          ========================
  Although the Virtual Pool movies can output sound to a variety of sound
  cards, Virtual Pool only uses Sound Blaster digitized sound for effects
  during the game.  If you have a different sound card, make sure that its
  Sound Blaster emulation is turned on.  Also, make sure that the BLASTER
  environment variable contains the correct settings.  See your sound
  card's installation procedures for more information.

                          ========================
                                Video Drivers
                          ========================
  Virtual pool can be run at higher resolutions with the 3DVX video
  drivers.  The drivers are graphics chip specific.  If you don't know what
  chip is on your video card, try using auto-detection in the config
  program.  Auto-detection is not guaranteed to work!  You can also try the
  VESA 1.2 driver.  The VESA driver may not work on some cards because they
  are not fully VESA 1.2 compliant.

  New drivers will be made available on the Interplay BBS (see below).

  There are hardware bugs in some early versions of the S3801/805 chipsets.
  You may see pixels reversed in columns on the screen.  The accelerator
  may not work on some chips.  There is no fix for these bugs.

  There are no drivers for Matrox chips.  Sorry, but Matrox refused to
  release information on their chips.

  If there isn't a driver for your board, let us know by posting a message
  on the Interplay BBS.  If we get a sufficient number of requests for a
  chip, we'll try to write a driver for it.  ISA graphics boards will not
  be supported because they lack the necessary performance for Virtual Pool
  at high resolution.

  The movie player uses a VESA mode.  If you can't play movies and get a
  message that the graphics mode can't be set, try installing a VESA
  driver.

                           =======================
                            Running under Windows
                           =======================
  
  To play Virtual Pool under Windows, use the SETUP program to install the
  game, and start the game by clicking on the Virtual Pool Icon.  Starting
  Virtual Pool from a DOS window is not recommended.

  Be sure to quit any other Windows programs BEFORE starting Virtual Pool,
  as other applications may cause audio and video problems in the game.
  There may not be enough memory to run Virtual Pool with other
  applications running.

  Virtual Pool is a DOS program.  The Windows setup program, and the
  ability to launch the program from an icon in Windows are provided as a
  convenience.  If you experience problems while playing under Windows,
  exit Windows and try running Virtual Pool from DOS.
  
                           ======================
                           Known Windows Problems
                           ======================
  The ET4000 Accelerated Chipset will not work under WINDOWS.  If you have
  a card with this chipset use the non-accelerated driver if you are
  running under Windows.

  Some older Sound Blaster and Media Vision cards will not function under
  WINDOWS.  If you're having problems getting the sound to work while
  playing from WINDOWS, and are getting a "sound device in use message",
  close any application that may be using sound.  If you still get the
  message the problem is a sound driver bug.  You can probably download an
  updated sound driver from your board manufacturer.  Creative Labs has a
  new driver for older Sound Blaster cards.

  Selecting Sound Blaster sound when configuring Virtual Pool under Windows
  may cause the movie player to hang.  If you configure Virtual Pool in
  Windows and select Sound Blaster, restart Windows before playing any
  movies.  You must hit ESC to bypass the movies at the start of Virtual
  Pool.

  If Virtual Pool does not work after a screen saver has been activated,
  disable your screen saver.  The Windows screen saver can be disabled by
  going to Main, select Control Panel, select Desktop, and change the name
  of the screen saver to None.

  The Windows setup program does not set the icon properties correctly 
  when installing under Windows 95. After installation set program name to
  "path"\vpool.pif, where "path" is the destination directory you specified
  during setup. The work directory should also be set to "path".

                          ========================
                                 Trick Shots
                          ========================
  If you make your own trick shots they will appear in the game under the
  name you saved them under, but the names in DOS will be different.  The
  naming convention for trick shots in DOS is GAMExxxx.PT, where the x's
  represent numbers which are used for identification.  As you save shots,
  these numbers increment automatically.  On the trick shot LOAD menu,
  these numbers are printed to the right of each trick shot to help you
  identify the shots from DOS.

  Problems?  Call Interplay Technical Support at 714.553.6678 or call one
  of the services listed below:


                          ========================
                                Interplay BBS
                          ========================
  Interplay operates a Multi-Line BBS running WildCat!  Software for
  Customer Support, Questions, and game fixes.  The number is 714-252-2822.
  Modem settings are 300-28.8k, V.32, V.42, 8-N-1.  This is a FREE service.

  After logging onto the Interplay BBS, join the Virtual Pool Conference,
  (conference 7).  To do this from the MAIN MENU, first type "M" to switch
  to the MESSAGE MENU, then type "J" for "JOIN," then enter "7" to join
  Conference 7.  Once you have switched to the Virtual Pool Conference you
  can (R)ead Messages left by others, (E)nter New Messages to our resident
  Virtual Pool Expert, and even download additional trick shots, (if you
  have the CD-ROM version of Virtual Pool).

  To Download Files, join Conference 7 as described above, type "F" for the
  FILES MENU, and then enter "L" to LIST the available files in this area.

                          ========================
                               IMPORTANT NOTE
                          ========================
  Different File Areas are available depending on which Conference you are
  currently in.  If you're looking for Virtual Pool files, be sure to
  (J)oin Conference 7 BEFORE you enter the (F)ile Area.

                          ========================
                               America Online
                          ========================
  From AOL you can e-mail Interplay Customer Support at IPTECH.  To reach
  our customer board in the Industry Connection, press CTRL-K for "Go to
  Keyword."  Then type INTERPLAY in the keyword window.  In addition to
  reading and leaving messages, you can download fixes and demos from the
  "Software Libraries."

                          ========================
                                 CompuServe
                          ========================
  On CompuServe we are located in the Game Publishers B Forum.  Just type
  GO GAMEPUB at any ! prompt.  Then select section 4 for Interplay
  Productions.  You can leave technical support questions there.  You can
  also download fixes and demos from Library 4 in the GAMEPUB.  The best
  place for game play hints is in the GAMERS forum, (type GO GAMERS).
  
  If you are not already a CompuServe member, you can call CompuServe toll-
  free at 1-800-524-3388 and ask Representative #354 for a free
  introductory membership and a $15 usage credit.

                          ========================
                                    GEnie
                          ========================
  We are located in the Games RoundTable hosted by Scorpia.  To get there,
  type M805;1 at any ? prompt.  Then select "Category 13" for Interplay
  Productions.  Demos and patches are available in the Libraries.

               ==============================================
                  Prodigy (r) Interactive Personal Service
               ==============================================
  You may send e-mail directly to us from Prodigy at ID PLAY99B.

                          ========================
                                  Internet
                          ========================
  You can reach Interplay Technical Support over the Internet by addressing
  e-mail to:  support@interplay.com

  Many Interplay demos and patches are also available at Internet FTP
  sites.
